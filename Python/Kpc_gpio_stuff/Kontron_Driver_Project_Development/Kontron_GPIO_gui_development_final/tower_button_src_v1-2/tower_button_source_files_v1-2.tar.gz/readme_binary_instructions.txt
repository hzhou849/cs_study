#Copyright 2017 Covidien LP.
#All Rights Reserved. The information contained herein is confidential
#property of Covidien LP. The use, copying, transfer or disclosure of such
#information is prohibited except by express written agreement with Covidien LP.


Ubuntu x86 Tower Button Test Script v1.2

1. Download the binary tower_button_test_v1-2_binary.tar.gz file from agile to an Ubuntu 14.04 (or higher)
   test PC.

2. Extract and run 'start_gpio' by typing in a new terminal window:
NOTE: scripts must be executed in folder where scripts are contained
 
	i) 'cd <path to scripts>/' press enter
	ii) './start_gpio'
