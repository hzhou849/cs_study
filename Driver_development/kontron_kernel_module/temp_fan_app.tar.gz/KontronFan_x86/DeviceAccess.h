// Copyright 2016 Covidien LP.
// All Rights Reserved. The information contained herein is confidential
// property of Covidien. The use, copying, transfer or disclosure of such
// information is prohibited except by written agreement with Covidien.


enum class DeviceAccess
{
    NONE,
    READ,
    WRITE,
    READ_WRITE
};


