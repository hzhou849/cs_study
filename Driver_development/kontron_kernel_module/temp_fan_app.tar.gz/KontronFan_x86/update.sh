#! /bin/bash

c++ -std=c++11 -pthread -fpermissive main.cpp -o kontron
