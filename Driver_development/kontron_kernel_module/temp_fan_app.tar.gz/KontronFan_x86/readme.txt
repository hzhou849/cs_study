qnx specific headers

<sys/mman.h>
<sys/neutrino.h>
<sys/procmgr.h>
