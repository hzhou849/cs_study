// Copyright 2017 Covidien LP.
// All Rights Reserved. The information contained herein is confidential
// property of Covidien. The use, copying, transfer or disclosure of such
// information is prohibited except by written agreement with Covidien.

#include <sys/types.h>
#include <chrono>
#include <iostream>
#include <string>
#include <array>
#include <thread>

//#include <sys/neutrino.h>

#include "kontron_driver/DeviceDriver.h"


void readIte8516GpioInputs()
{
    try
    {
       einstein::kontron_driver::DeviceDriver driver;

        auto version = driver.getFirmwareVersion();
        std::printf("ite8516 firmware version: %02x.%02x.%02x.%02x\n",
                (version >> 24) & 0xFF, (version >> 16) & 0xFF, (version >> 8) & 0xFF, (version >> 0) & 0xFF);

        std::array<std::uint32_t, einstein::kontron_driver::Device::NUM_GPIO> states;
        states.fill(0);

        for (einstein::kontron_driver::DeviceDriver::GpioChannelIndex i = 0; i < einstein::kontron_driver::Device::NUM_GPIO;  ++i)
        {
            if (driver.canSetGpioDirection(i, einstein::kontron_driver::DeviceDriver::GpioDirection::INPUT))
            {
                driver.setGpioDirection(i, einstein::kontron_driver::DeviceDriver::GpioDirection::INPUT);
            }
            std::uint32_t state = driver.getGpioInput(i);
            std::printf("GPIO %2d in  = %d\n", i, state);
            states[i] = state;
        }

        while (true)
        {
            for (einstein::kontron_driver::DeviceDriver::GpioChannelIndex i = 0; i < einstein::kontron_driver::Device::NUM_GPIO;  ++i)
            {
                std::uint32_t state = driver.getGpioInput(i);
                if (state != states[i])
                {
                    std::printf("GPIO %2d in  = %d\n", i, state);
                    states[i] = state;
                }
            }
        }
    }
    catch (const std::exception & e)
    {
        std::cerr << "Caught exception:\n  " << e.what() << '\n';
    }
}

int readIte8516MonitoringInputs_quiet()
{
    try
    {
        einstein::kontron_driver::DeviceDriver driver;
     
        double cpu_temp = driver.getTemperature(0);
        double sys_temp = driver.getTemperature(1);
        std::uint32_t cpu_fan_speed = driver.getFanSpeed(0);
        std::uint32_t sys_fan_speed = driver.getFanSpeed(1);
        std::uint32_t f3_fan_speed = driver.getFanSpeed(2);
        std::uint32_t f4_fan_speed = driver.getFanSpeed(3);
        
        std::printf("\rTemp: CPU = %5.1lf SYS = %5.1lf; Fan RPM: CPU %4d, SYS %4d, c %4d, d %4d\n",
                    cpu_temp, sys_temp, cpu_fan_speed, sys_fan_speed, f3_fan_speed, f4_fan_speed);
    }
    catch (const std::exception & e)
    {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    
    return 0;
}

int readIte8516MonitoringInputs()
{
    try
    {
        einstein::kontron_driver::DeviceDriver driver;

        auto version = driver.getFirmwareVersion();
        std::printf("ite8516 firmware version: %02x.%02x.%02x.%02x\n",
                (version >> 24) & 0xFF, (version >> 16) & 0xFF, (version >> 8) & 0xFF, (version >> 0) & 0xFF);

       
            double cpu_temp = driver.getTemperature(0);
            double sys_temp = driver.getTemperature(1);
            std::uint32_t cpu_fan_speed = driver.getFanSpeed(0);
            std::uint32_t sys_fan_speed = driver.getFanSpeed(1);
            std::uint32_t f3_fan_speed = driver.getFanSpeed(2);
            std::uint32_t f4_fan_speed = driver.getFanSpeed(3);
    
            std::printf("\rTemp: CPU = %5.1lf SYS = %5.1lf; Fan RPM: CPU %4d, SYS %4d, c %4d, d %4d\n",
                    cpu_temp, sys_temp, cpu_fan_speed, sys_fan_speed, f3_fan_speed, f4_fan_speed);  
               
    }
    catch (const std::exception & e)
    {
        std::cerr << "Caught exception: " << e.what() << std::endl;
    }
    
    return 0;
}


int main(int argc, char ** argv)
{
    std::string strgpio ("gpio");
    std::string strcpu ("cpu");
    std::string strq   ("-q");

    if (argc < 2)
    {
        std::cerr << "Unexpected arguments: " << std::endl;
        return -1;
    }

    // int status = ThreadCtl(_NTO_TCTL_IO, 0);
    // if (status == -1)
    // {
    //     std::cerr << "Setting up _NTO_TCTL_IO failed" << std::endl;
    // }

    if (strgpio.compare(argv[1]) == 0)
    {
        if (argc == 2) 
        {
            readIte8516GpioInputs();
        }
        else
        {
            std::cerr << "Unexpected arguments: " << std::endl;
            return -1;
        }
    }
    else if ((argc == 3) && (strq.compare(argv[2]) == 0)) 
    {
        readIte8516MonitoringInputs_quiet();
    }
    else if (strcpu.compare(argv[1]) == 0)
    {
        readIte8516MonitoringInputs();    
    }
    else
    {
        std::cerr << "Unexpected arguments: " << argv[1] << std::endl;
    }
}

