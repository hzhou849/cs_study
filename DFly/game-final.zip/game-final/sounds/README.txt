Sprite art:

Mark Claypool

Music:

start-music - "Jungle Starvation", by RepaidGateman 
http://www.flashkit.com/loops/Ambient/Electronica/Jungle_S-RepaidGa-10582/index.php

Sound Effects:

fire - "laser", by domson
http://www.flashkit.com/imagesvr_ce/flashkit/soundfx/Ambience/laser-domson-8694/laser-domson-8694_hifi.mp3

explode - "Weird Explosion", by Angler
http://www.flashkit.com/soundfx/Mayhem/Explosives/Weird_Ex-Angler-8806/index.php

nuke - "Nuklear Explosion", by Staberxpert
http://www.flashkit.com/soundfx/Cartoon/Explosions/Nuklear_-Staberxp-8147/index.php

game over - BOOOOOMMM!!!, by Katanaman
http://www.flashkit.com/imagesvr_ce/flashkit/soundfx/Cartoon/Explosions/BOOOOOMM-Katanama-7525/BOOOOOMM-Katanama-7525_hifi.mp3